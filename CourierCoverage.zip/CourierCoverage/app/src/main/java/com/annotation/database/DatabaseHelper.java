package com.annotation.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import com.annotation.couriercoverage.R;
import com.annotation.pojo.AdminPojo;
import com.annotation.pojo.CustomerPojo;
import com.annotation.pojo.RequestPojo;
import com.annotation.pojo.StaffPojo;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME="courier.db";
    public static final String ADMIN_TABLE_NAME="admin";
    public static final String ADMIN_COL_1="a_id";
    public static final String ADMIN_COL_2="a_uname";
    public static final String ADMIN_COL_3="a_pass";

    public static final String CUSTOMER_TABLE_NAME="customer";
    public static final String CUSTOMER_COL_1="c_id";
    public static final String CUSTOMER_COL_2="c_name";
    public static final String CUSTOMER_COL_3="c_uname";
    public static final String CUSTOMER_COL_4="c_pass";
    public static final String CUSTOMER_COL_5="c_email";
    public static final String CUSTOMER_COL_6="c_dob";
    public static final String CUSTOMER_COL_7="c_gender";
    public static final String CUSTOMER_COL_8="c_addr";
    public static final String CUSTOMER_COL_9="c_contact";


    public static final String STAFF_TABLE_NAME="staff";
    public static final String STAFF_COL_1="s_id";
    public static final String STAFF_COL_2="s_name";
    public static final String STAFF_COL_3="s_uname";
    public static final String STAFF_COL_4="s_pass";
    public static final String STAFF_COL_5="s_email";
    public static final String STAFF_COL_6="s_dob";
    public static final String STAFF_COL_7="s_gender";
    public static final String STAFF_COL_8="s_addr";
    public static final String STAFF_COL_9="s_contact";

    public static final String REQUEST_TABLE_NAME="request";
    public static final String REQUEST_COL_1="r_id";
    public static final String REQUEST_COL_2="r_description";
    public static final String REQUEST_COL_3="r_wt";
    public static final String REQUEST_COL_4="r_from";
    public static final String REQUEST_COL_5="r_to";
    public static final String REQUEST_COL_6="r_recpt_name";
    public static final String REQUEST_COL_7="r_recpt_contact";
    public static final String REQUEST_COL_8="r_status";
    public static final String REQUEST_COL_9="r_cost";
    public static final String REQUEST_COL_10="r_dop";
    public static final String REQUEST_COL_11="r_c_id";
    public static final String REQUEST_COL_12="r_s_id";
    public static final String REQUEST_COL_13="r_location";

    public DatabaseHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table admin (a_id integer primary key autoincrement,a_uname text,a_pass text)");
        db.execSQL("create table customer (c_id integer primary key autoincrement,c_name text,c_uname text,c_pass text,c_email text,c_dob text,c_gender text,c_addr text,c_contact text)");
        db.execSQL("create table staff (s_id integer primary key autoincrement,s_name text,s_uname text,s_pass text,s_email text,s_dob text,s_gender text,s_addr text,s_contact text)");
        db.execSQL("create table request (r_id integer primary key autoincrement,r_description text,r_wt text,r_from text,r_to text,r_recpt_name text,r_recpt_contact,r_status text,r_cost text,r_dop text,r_c_id integer,r_s_id integer,r_location text,FOREIGN KEY(r_c_id) REFERENCES customer(c_id),FOREIGN KEY(r_s_id) REFERENCES staff(s_id))");
        createAdmin(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {

    }
     public void createAdmin(SQLiteDatabase db) {
        ContentValues contentValues=new ContentValues();
        contentValues.put(ADMIN_COL_2,"Admin");
        contentValues.put(ADMIN_COL_3,"Admin123");
        db.insert(ADMIN_TABLE_NAME,null,contentValues);
        db.close();
    }

    public boolean adminLogin(AdminPojo adminPojo)
    {
        String uname,  pass;
        uname=adminPojo.getAdmin_uanme();
        pass=adminPojo.getAdmin_pass();
      SQLiteDatabase db  = getReadableDatabase();
      Cursor res=db.rawQuery("select * from admin where a_uname='"+uname+"' and a_pass='"+pass+"'",null);

      if(res.moveToFirst())
          return  true;
      else
          return false;
    }

    public boolean customerLogin(CustomerPojo customerPojo)
    {
        String uname,  pass;
        uname=customerPojo.getC_uname();
        pass=customerPojo.getC_pass();
        SQLiteDatabase db  = getReadableDatabase();
        Cursor res=db.rawQuery("select * from customer where c_uname='"+uname+"' and c_pass='"+pass+"'",null);

        if(res.moveToFirst())
            return  true;
        else
            return false;
    }

    public int getCustomerId(CustomerPojo customerPojo)
    {
        String uname,  pass;
        int c_id = 0;
        uname=customerPojo.getC_uname();
        pass=customerPojo.getC_pass();
        SQLiteDatabase db  = getReadableDatabase();
        Cursor res=db.rawQuery("select c_id from customer where c_uname='"+uname+"' and c_pass='"+pass+"'",null);
        if(res!= null && res.moveToFirst()){
            do{
                c_id=res.getInt(res.getColumnIndex("c_id"));
            }while (res.moveToNext());
        }
        
        return c_id;
    }

    public boolean staffLogin(StaffPojo staffPojo)
    {
        String uname,  pass;
        uname=staffPojo.getS_uname();
        pass=staffPojo.getS_pass();
        SQLiteDatabase db  = getReadableDatabase();
        Cursor res=db.rawQuery("select * from staff where s_uname='"+uname+"' and s_pass='"+pass+"'",null);
        if(res.moveToFirst())
            return  true;
        else
            return false;
    }

    public int getStaffId(StaffPojo staffPojo)
    {
        String uname,  pass;
        int s_id = 0;
        uname=staffPojo.getS_uname();
        pass=staffPojo.getS_pass();
        SQLiteDatabase db  = getReadableDatabase();
        Cursor res=db.rawQuery("select s_id from staff where s_uname='"+uname+"' and s_pass='"+pass+"'",null);
        if(res!= null && res.moveToFirst()){
            do{
                s_id=res.getInt(res.getColumnIndex("s_id"));
            }while (res.moveToNext());
        }

        return s_id;
    }


    public long customerRegister(CustomerPojo customerPojo)
    {
        long res;
        SQLiteDatabase db=getWritableDatabase();
        ContentValues contentValues=new ContentValues();

        contentValues.put(CUSTOMER_COL_2,customerPojo.getC_name());
        contentValues.put(CUSTOMER_COL_3,customerPojo.getC_uname());
        contentValues.put(CUSTOMER_COL_4,customerPojo.getC_pass());
        contentValues.put(CUSTOMER_COL_5,customerPojo.getC_email());
        contentValues.put(CUSTOMER_COL_6,customerPojo.getC_dob());
        contentValues.put(CUSTOMER_COL_7,customerPojo.getC_gender());
        contentValues.put(CUSTOMER_COL_8,customerPojo.getC_addr());
        contentValues.put(CUSTOMER_COL_9,customerPojo.getC_contact());

        res= db.insert(CUSTOMER_TABLE_NAME,null,contentValues);
        return res;

    }

    public long addStaff(StaffPojo staffPojo)
    {
        long res;
        SQLiteDatabase db=getWritableDatabase();
        ContentValues contentValues=new ContentValues();

        contentValues.put(STAFF_COL_2,staffPojo.getS_name());
        contentValues.put(STAFF_COL_3,staffPojo.getS_uname());
        contentValues.put(STAFF_COL_4,staffPojo.getS_pass());
        contentValues.put(STAFF_COL_5,staffPojo.getS_email());
        contentValues.put(STAFF_COL_6,staffPojo.getS_dob());
        contentValues.put(STAFF_COL_7,staffPojo.getS_gender());
        contentValues.put(STAFF_COL_8,staffPojo.getS_addr());
        contentValues.put(STAFF_COL_9,staffPojo.getS_contact());

        res= db.insert(STAFF_TABLE_NAME,null,contentValues);
        return res;

    }

    public long addRequest(RequestPojo requestPojo)
    {
        long res;
        SQLiteDatabase db=getWritableDatabase();
        ContentValues contentValues=new ContentValues();

        contentValues.put(REQUEST_COL_2,requestPojo.getR_description());
        contentValues.put(REQUEST_COL_3,requestPojo.getR_wt());
        contentValues.put(REQUEST_COL_4,requestPojo.getR_from());
        contentValues.put(REQUEST_COL_5,requestPojo.getR_to());
        contentValues.put(REQUEST_COL_6,requestPojo.getR_recpt_name());
        contentValues.put(REQUEST_COL_7,requestPojo.getR_recpt_contact());
        contentValues.put(REQUEST_COL_8,requestPojo.getR_status());
        contentValues.put(REQUEST_COL_9,requestPojo.getR_cost());
        contentValues.put(REQUEST_COL_10,requestPojo.getR_dop());
        contentValues.put(REQUEST_COL_11,requestPojo.getR_c_id());
        contentValues.put(REQUEST_COL_12,requestPojo.getR_s_id());
        contentValues.put(REQUEST_COL_13,requestPojo.getR_location());

        res= db.insert(REQUEST_TABLE_NAME,null,contentValues);
        db.close();
        return res;


    }

    public List<StaffPojo> viewStaff() {
        List<StaffPojo> stafflist = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(STAFF_TABLE_NAME, null, null, null, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            do {
                StaffPojo staffPojo = new StaffPojo();

                staffPojo.setS_id(cursor.getInt(cursor.getColumnIndex(STAFF_COL_1)));
                staffPojo.setS_name(cursor.getString(cursor.getColumnIndex(STAFF_COL_2)));
                stafflist.add(staffPojo);
            } while (cursor.moveToNext());
        }
        return stafflist;
    }

    public List<RequestPojo> viewAdminPendingRequest() {
        List<RequestPojo> requestlist = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from request where r_status='"+null+"'",null);
        if (cursor != null && cursor.moveToFirst()) {
            do {
                RequestPojo requestPojo = new RequestPojo();

                requestPojo.setR_id(cursor.getInt(cursor.getColumnIndex(REQUEST_COL_1)));
                requestPojo.setR_description(cursor.getString(cursor.getColumnIndex(REQUEST_COL_2)));
                requestPojo.setR_c_id(cursor.getInt(cursor.getColumnIndex(REQUEST_COL_11)));
                requestlist.add(requestPojo);
            } while (cursor.moveToNext());
        }
        return requestlist;
    }

    public List<RequestPojo> viewAdminApprovedRequest() {
        List<RequestPojo> requestlist = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from request where r_status='"+"Approved"+"'",null);
        if (cursor != null && cursor.moveToFirst()) {
            do {
                RequestPojo requestPojo = new RequestPojo();

                requestPojo.setR_id(cursor.getInt(cursor.getColumnIndex(REQUEST_COL_1)));
                requestPojo.setR_description(cursor.getString(cursor.getColumnIndex(REQUEST_COL_2)));
                requestPojo.setR_c_id(cursor.getInt(cursor.getColumnIndex(REQUEST_COL_11)));
                requestlist.add(requestPojo);
            } while (cursor.moveToNext());
        }
        return requestlist;
    }

    public List<RequestPojo> viewStaffPendingRequest(int s_id) {
        List<RequestPojo> requestlist = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from request where r_s_id='"+s_id+"'",null);
        if (cursor != null && cursor.moveToFirst()) {
            do {
                RequestPojo requestPojo = new RequestPojo();

                requestPojo.setR_id(cursor.getInt(cursor.getColumnIndex(REQUEST_COL_1)));
                requestPojo.setR_description(cursor.getString(cursor.getColumnIndex(REQUEST_COL_2)));
                requestPojo.setR_c_id(cursor.getInt(cursor.getColumnIndex(REQUEST_COL_11)));
                requestlist.add(requestPojo);
            } while (cursor.moveToNext());
        }
        return requestlist;
    }

    public RequestPojo requestInfo(int id)
    {
         RequestPojo requestPojo = new RequestPojo();
        SQLiteDatabase db=getReadableDatabase();
        Cursor cursor=db.rawQuery("select * from request where r_id='"+id+"'",null);
        if(cursor!=null && cursor.moveToFirst()){
            do {
                requestPojo.setR_id(cursor.getInt(cursor.getColumnIndex(REQUEST_COL_1)));
                requestPojo.setR_description(cursor.getString(cursor.getColumnIndex(REQUEST_COL_2)));
                requestPojo.setR_wt(cursor.getString(cursor.getColumnIndex(REQUEST_COL_3)));
                requestPojo.setR_from(cursor.getString(cursor.getColumnIndex(REQUEST_COL_4)));
                requestPojo.setR_to(cursor.getString(cursor.getColumnIndex(REQUEST_COL_5)));
                requestPojo.setR_recpt_name(cursor.getString(cursor.getColumnIndex(REQUEST_COL_6)));
                requestPojo.setR_recpt_contact(cursor.getString(cursor.getColumnIndex(REQUEST_COL_7)));
                requestPojo.setR_status(cursor.getString(cursor.getColumnIndex(REQUEST_COL_8)));
                requestPojo.setR_cost(cursor.getString(cursor.getColumnIndex(REQUEST_COL_9)));
                requestPojo.setR_dop(cursor.getString(cursor.getColumnIndex(REQUEST_COL_10)));
                requestPojo.setR_c_id(cursor.getInt(cursor.getColumnIndex(REQUEST_COL_11)));
                requestPojo.setR_s_id(cursor.getInt(cursor.getColumnIndex(REQUEST_COL_12)));
                requestPojo.setR_location(cursor.getString(cursor.getColumnIndex(REQUEST_COL_13)));
            }while (cursor.moveToNext());

        }
        return requestPojo;
    }

    public int updateStatus(RequestPojo requestPojo)
    {
        int res;
        int id=requestPojo.getR_id();
        SQLiteDatabase db=getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put(REQUEST_COL_12,requestPojo.getR_s_id());
        contentValues.put(REQUEST_COL_9,requestPojo.getR_cost());
        contentValues.put(REQUEST_COL_8,"Approved");
        res=db.update(REQUEST_TABLE_NAME,contentValues, REQUEST_COL_1+"=?",new String[]{Integer.toString(id)});
        return res;
    }

    public int updateLocation(RequestPojo requestPojo)
    {
        int res;
        int id=requestPojo.getR_id();
        SQLiteDatabase db=getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put(REQUEST_COL_13,requestPojo.getR_location());
        res=db.update(REQUEST_TABLE_NAME,contentValues, REQUEST_COL_1+"=?",new String[]{Integer.toString(id)});
        return res;
    }

    public List<RequestPojo> viewCustomerRequest(int c_id) {
        List<RequestPojo> requestlist = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from request where r_c_id='"+c_id+"'",null);
        if (cursor != null && cursor.moveToFirst()) {
            do {
                RequestPojo requestPojo = new RequestPojo();

                requestPojo.setR_id(cursor.getInt(cursor.getColumnIndex(REQUEST_COL_1)));
                requestPojo.setR_description(cursor.getString(cursor.getColumnIndex(REQUEST_COL_2)));
                requestPojo.setR_c_id(cursor.getInt(cursor.getColumnIndex(REQUEST_COL_11)));
                requestlist.add(requestPojo);
            } while (cursor.moveToNext());
        }
        return requestlist;
    }
}
