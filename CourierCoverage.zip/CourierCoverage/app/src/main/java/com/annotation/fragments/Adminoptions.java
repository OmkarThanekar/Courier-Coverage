package com.annotation.fragments;


import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.annotation.couriercoverage.Admin;
import com.annotation.couriercoverage.LoginOptions;
import com.annotation.couriercoverage.R;

/**
 * A simple {@link Fragment} subclass.
 */
public class Adminoptions extends Fragment implements View.OnClickListener {

    ImageView iv_addstaff;
    ImageView iv_viewstaff;
    ImageView iv_view_pending_request;
    ImageView iv_view_approved_request;
    TextView tv_logout;

    ConstraintLayout constraintLayout;

    Button btn_addstaff;
    Button btn_viewstaff;
    Button btn_view_pending_request;
    Button btn_view_approved_request;

    public Adminoptions() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_adminoptions,container,false);
        view.setFocusableInTouchMode(true);
        view.requestFocus();
        final int sdk = android.os.Build.VERSION.SDK_INT;

        view.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                Log.i("##tag", "keyCode: " + keyCode);

                if( keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_UP) {
//                    Log.i("##confirmation", "onKey Back listener is working!!!");

                   logout();
                    return true;
                }
                return false;
            }

        });
        initViews(view);
        if(sdk > Build.VERSION_CODES.KITKAT) {
            constraintLayout.setBackground(ContextCompat.getDrawable(getActivity(), R.drawable.background));

        }
        initListeners();


        return view;
    }

    private void logout() {
        final android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(getActivity());

        builder.setTitle("Log Out?");
        builder.setMessage("Do you really want to log out.");
        builder.setPositiveButton("Yes", new DialogInterface
                .OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog,
                                int which) {
                getFragmentManager().popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
                Intent intent = new Intent(getActivity().getApplicationContext(), LoginOptions.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);

            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        builder.setCancelable(false);
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    private void initListeners() {
        btn_viewstaff.setOnClickListener(this);
        btn_addstaff.setOnClickListener(this);
        btn_view_pending_request.setOnClickListener(this);
        btn_view_approved_request.setOnClickListener(this);

        tv_logout.setOnClickListener(this);
    }


    private void initViews(View view) {
        iv_addstaff=view.findViewById(R.id.fragment_admin_options_iv_add_staff);
        iv_viewstaff=view.findViewById(R.id.fragment_admin_options_iv_view_staff);
        iv_view_pending_request=view.findViewById(R.id.fragment_admin_options_iv_view_pending_request);
        iv_view_approved_request=view.findViewById(R.id.fragment_admin_options_iv_view_approved_request);
        tv_logout=view.findViewById(R.id.tv_logout);

        btn_addstaff=view.findViewById(R.id.fragment_admin_options_btn_add_staff);
        btn_view_pending_request=view.findViewById(R.id.fragment_admin_options_btn_view_pending_requests);
        btn_view_approved_request=view.findViewById(R.id.fragment_admin_options_btn_view_approved_requests);
        btn_viewstaff=view.findViewById(R.id.fragment_admin_options_btn_view_staff);

        constraintLayout=view.findViewById(R.id.fragment_admin_options_cl);
    }


    @Override
    public void onClick(View view) {
        switch (view.getId())
        {
            case R.id.fragment_admin_options_btn_add_staff:
                FragmentManager fragmentManager=getActivity().getSupportFragmentManager();
                FragmentTransaction fragmentTransaction=fragmentManager.beginTransaction();
                Adminaddstaff adminaddstaff=new Adminaddstaff();
                fragmentTransaction.replace(R.id.main_admin_fl_container,adminaddstaff,adminaddstaff.getTag()).commit();
                fragmentTransaction.addToBackStack(adminaddstaff.getTag());
                break;
            case R.id.fragment_admin_options_btn_view_staff:
                FragmentManager fragmentManager1=getActivity().getSupportFragmentManager();
                FragmentTransaction fragmentTransaction1=fragmentManager1.beginTransaction();
                ViewStaff viewStaff=new ViewStaff();
                fragmentTransaction1.replace(R.id.main_admin_fl_container,viewStaff,viewStaff.getTag()).commit();
                fragmentTransaction1.addToBackStack(viewStaff.getTag());

                break;
            case R.id.fragment_admin_options_btn_view_pending_requests:

                ViewRequest viewRequest=new ViewRequest();
                Bundle args=new Bundle();
                args.putString("user","admin");
                args.putString("mode","pending");
                viewRequest.setArguments(args);
                FragmentManager fragmentManager2=getActivity().getSupportFragmentManager();
                FragmentTransaction fragmentTransaction2=fragmentManager2.beginTransaction();
                fragmentTransaction2.replace(R.id.main_admin_fl_container,viewRequest,viewRequest.getTag()).commit();
                fragmentTransaction2.addToBackStack(viewRequest.getTag());
                break;

            case R.id.fragment_admin_options_btn_view_approved_requests:
                ViewRequest viewRequest1=new ViewRequest();
                Bundle args1=new Bundle();
                args1.putString("user","admin");
                args1.putString("mode","approved");
                viewRequest1.setArguments(args1);
                FragmentManager fragmentManager3=getActivity().getSupportFragmentManager();
                FragmentTransaction fragmentTransaction3=fragmentManager3.beginTransaction();
                fragmentTransaction3.replace(R.id.main_admin_fl_container,viewRequest1,viewRequest1.getTag()).commit();
                fragmentTransaction3.addToBackStack(viewRequest1.getTag());
                break;

            case R.id.tv_logout:
                logout();
                break;
        }

    }

}
