package com.annotation.pojo;

public class AdminPojo {
    private int admin_id;
    private String admin_uanme;
    private String admin_pass;

    public int getAdmin_id() {
        return admin_id;
    }

    public void setAdmin_id(int admin_id) {
        this.admin_id = admin_id;
    }

    public String getAdmin_uanme() {
        return admin_uanme;
    }

    public void setAdmin_uanme(String admin_uanme) {
        this.admin_uanme = admin_uanme;
    }

    public String getAdmin_pass() {
        return admin_pass;
    }

    public void setAdmin_pass(String admin_pass) {
        this.admin_pass = admin_pass;
    }
}
