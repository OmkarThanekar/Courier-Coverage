package com.annotation.couriercoverage;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;

import com.annotation.fragments.CustomerLogin;

public class Customer extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer);
        ActionBar actionBar=getSupportActionBar();
        actionBar.setTitle("CUSTOMER PANEL");
        loadfragment();
    }

    private void loadfragment() {
        FragmentManager fragmentManager=getSupportFragmentManager();
        FragmentTransaction fragmentTransaction=fragmentManager.beginTransaction();
        CustomerLogin customerLogin=new CustomerLogin();
        fragmentTransaction.add(R.id.main_customer_fl_container,customerLogin,customerLogin.getTag()).commit();
    }
}
