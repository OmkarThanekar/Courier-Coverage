package com.annotation.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.annotation.couriercoverage.R;
import com.annotation.pojo.StaffPojo;

import java.util.List;

public class StaffAdapter extends BaseAdapter {
    private Context context;
    private LayoutInflater inflater;
    private List<StaffPojo> item;

    public StaffAdapter(Context c, List<StaffPojo> item) {
        context=c;
        this.item=item;
    }

    @Override
    public int getCount() {
        return item.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        if (inflater==null){
            inflater=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }
        if (view==null){
            view=inflater.inflate(R.layout.view_staff_item,null);
        }
        TextView tv_id=view.findViewById(R.id.s_id);
        TextView tv_name=view.findViewById(R.id.s_name);
        StaffPojo staffPojo=item.get(i);
        tv_id.setText(Integer.toString(staffPojo.getS_id()));
        tv_name.setText(staffPojo.getS_name());
        return view;
    }
}
