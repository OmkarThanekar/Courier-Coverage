package com.annotation.couriercoverage;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;

import com.annotation.fragments.AdminLogin;
import com.annotation.fragments.StaffLogin;

public class Staff extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_staff);
        ActionBar actionBar=getSupportActionBar();
        actionBar.setTitle("STAFF PANEL");
        loadfragment();
    }
    private void loadfragment() {
        FragmentManager fragmentManager=getSupportFragmentManager();
        FragmentTransaction fragmentTransaction=fragmentManager.beginTransaction();
        StaffLogin staffLogin=new StaffLogin();
        fragmentTransaction.add(R.id.main_staff_fl_container,staffLogin,staffLogin.getTag()).commit();
    }
}
