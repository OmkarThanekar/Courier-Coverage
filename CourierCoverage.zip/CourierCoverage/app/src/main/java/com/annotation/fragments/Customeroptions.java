package com.annotation.fragments;


import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.annotation.couriercoverage.LoginOptions;
import com.annotation.couriercoverage.R;

/**
 * A simple {@link Fragment} subclass.
 */
public class Customeroptions extends Fragment implements View.OnClickListener {

    int c_id;

    ImageView iv_sendreq;
    ImageView iv_viewstatus;
    TextView tv_logout;
    ConstraintLayout constraintLayout;

    Button btn_sendreq;
    Button btn_viewstatus;


    public Customeroptions() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_customeroptions,container,false);
        view.setFocusableInTouchMode(true);
        view.requestFocus();
        view.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                Log.i("##tag", "keyCode: " + keyCode);

                if( keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_UP) {
//                    Log.i("##confirmation", "onKey Back listener is working!!!");
                   logout();
                    return true;
                }
                return false;
            }

        });
        initViews(view);
        final int sdk = android.os.Build.VERSION.SDK_INT;
        if(sdk > Build.VERSION_CODES.KITKAT) {
            constraintLayout.setBackground(ContextCompat.getDrawable(getActivity(), R.drawable.custback));

        }
        initListeners();
        getKeys();
        return view;
    }

    private void logout() {
        final android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(getActivity());
        builder.setTitle("Log Out?");
        builder.setMessage("Do you really want to log out.");
        builder.setPositiveButton("Yes", new DialogInterface
                .OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog,
                                int which) {
                getFragmentManager().popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
                Intent intent = new Intent(getActivity().getApplicationContext(), LoginOptions.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);

            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        builder.setCancelable(false);
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    private void getKeys() {
        c_id=getArguments().getInt("CustomerId");
//        Toast.makeText(getContext(), Integer.toString(c_id), Toast.LENGTH_SHORT).show();
    }

    private void initListeners() {
        btn_sendreq.setOnClickListener(this);
        btn_viewstatus.setOnClickListener(this);
        tv_logout.setOnClickListener(this);
    }

    private void initViews(View view) {
        iv_sendreq=view.findViewById(R.id.fragment_customer_options_iv_send_request);
        iv_viewstatus=view.findViewById(R.id.fragment_customer_options_iv_view_status);

        btn_sendreq=view.findViewById(R.id.fragment_customer_options_btn_send_request);
        btn_viewstatus=view.findViewById(R.id.fragment_customer_options_btn_view_status);
        tv_logout=view.findViewById(R.id.tv_logout);
        constraintLayout=view.findViewById(R.id.fragment_customer_options_cl);
    }

    @Override
    public void onClick(View view) {
        switch(view.getId())
        {
            case R.id.fragment_customer_options_btn_send_request:
                CustomerRequest customerRequest=new CustomerRequest();
                Bundle args=new Bundle();
                args.putInt("CustomerId",c_id);
                customerRequest.setArguments(args);
                FragmentManager fragmentManager=getActivity().getSupportFragmentManager();
                FragmentTransaction fragmentTransaction=fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.main_customer_fl_container,customerRequest,customerRequest.getTag()).commit();
                fragmentTransaction.addToBackStack(customerRequest.getTag());

                break;
            case R.id.fragment_customer_options_btn_view_status:
//
//                Bundle args=new Bundle();
//                args.putInt("CustomerId",c_id);
//                customerRequest.setArguments(args);
                ViewRequest viewRequest=new ViewRequest();
                Bundle args1=new Bundle();
                args1.putString("user","customer");
                args1.putString("mode","view");
                args1.putInt("CustomerId",c_id);
                viewRequest.setArguments(args1);
                FragmentManager fragmentManager2=getActivity().getSupportFragmentManager();
                FragmentTransaction fragmentTransaction2=fragmentManager2.beginTransaction();
                fragmentTransaction2.replace(R.id.main_customer_fl_container,viewRequest,viewRequest.getTag()).commit();
                fragmentTransaction2.addToBackStack(viewRequest.getTag());
                break;
            case R.id.tv_logout:
                logout();
                break;
        }

    }
}
