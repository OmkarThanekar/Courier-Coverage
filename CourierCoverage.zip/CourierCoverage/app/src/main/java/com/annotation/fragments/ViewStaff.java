package com.annotation.fragments;


import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.Toast;

import com.annotation.Adapter.StaffAdapter;
import com.annotation.couriercoverage.R;
import com.annotation.database.DatabaseHelper;
import com.annotation.pojo.StaffPojo;

import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 */
public class ViewStaff extends Fragment {
ListView lv_staff;
StaffPojo staffPojo;
DatabaseHelper databaseHelper;

    public ViewStaff() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_view_staff,container,false);

        initViews(view);
        initListeners();
        databaseHelper=new DatabaseHelper(getActivity());
        populateData();
        return view;
    }

    private void populateData() {
        final List<StaffPojo> staffList=databaseHelper.viewStaff();
        StaffAdapter staffAdapter=new StaffAdapter(getContext(),staffList);
        lv_staff.setAdapter(staffAdapter);
//        Toast.makeText(getContext(), "get"+staffList.size(), Toast.LENGTH_SHORT).show();
    }

    private void initListeners() {
    }

    private void initViews(View view) {
        lv_staff=view.findViewById(R.id.fragment_view_saff_lv);
    }

}
