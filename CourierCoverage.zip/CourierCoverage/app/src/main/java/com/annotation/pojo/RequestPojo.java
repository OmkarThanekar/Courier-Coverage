package com.annotation.pojo;

public class RequestPojo {
    private int r_id;
    private String r_description;
    private String r_wt;
    private String r_from;
    private String r_to;
    private String r_recpt_name;
    private String r_recpt_contact;
    private String r_status;
    private String r_cost;
    private String r_dop;
    private int r_c_id;
    private int r_s_id;
    private String r_location;

    public String getR_location() {
        return r_location;
    }

    public void setR_location(String r_location) {
        this.r_location = r_location;
    }

    public int getR_id() {
        return r_id;
    }

    public void setR_id(int r_id) {
        this.r_id = r_id;
    }

    public String getR_description() {
        return r_description;
    }

    public void setR_description(String r_description) {
        this.r_description = r_description;
    }

    public String getR_wt() {
        return r_wt;
    }

    public void setR_wt(String r_wt) {
        this.r_wt = r_wt;
    }

    public String getR_from() {
        return r_from;
    }

    public void setR_from(String r_from) {
        this.r_from = r_from;
    }

    public String getR_to() {
        return r_to;
    }

    public void setR_to(String r_to) {
        this.r_to = r_to;
    }

    public String getR_recpt_name() {
        return r_recpt_name;
    }

    public void setR_recpt_name(String r_recpt_name) {
        this.r_recpt_name = r_recpt_name;
    }

    public String getR_recpt_contact() {
        return r_recpt_contact;
    }

    public void setR_recpt_contact(String r_recpt_contact) {
        this.r_recpt_contact = r_recpt_contact;
    }

    public String getR_status() {
        return r_status;
    }

    public void setR_status(String r_status) {
        this.r_status = r_status;
    }

    public String getR_cost() {
        return r_cost;
    }

    public void setR_cost(String r_cost) {
        this.r_cost = r_cost;
    }

    public String getR_dop() {
        return r_dop;
    }

    public void setR_dop(String r_dop) {
        this.r_dop = r_dop;
    }

    public int getR_c_id() {
        return r_c_id;
    }

    public void setR_c_id(int r_c_id) {
        this.r_c_id = r_c_id;
    }

    public int getR_s_id() {
        return r_s_id;
    }

    public void setR_s_id(int r_s_id) {
        this.r_s_id = r_s_id;
    }
}
