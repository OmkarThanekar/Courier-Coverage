package com.annotation.fragments;


import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.annotation.couriercoverage.LoginOptions;
import com.annotation.couriercoverage.R;
import com.annotation.database.DatabaseHelper;
import com.annotation.pojo.StaffPojo;
import com.annotation.pojo.StaffPojo;
import com.google.android.material.textfield.TextInputLayout;

import java.util.Calendar;

/**
 * A simple {@link Fragment} subclass.
 */
public class Adminaddstaff extends Fragment implements View.OnClickListener, DatePickerDialog.OnDateSetListener {

    String Setgender;
    DatabaseHelper databaseHelper;
    private  Calendar calendar;

    TextInputLayout til_staff_name;
    TextInputLayout til_staff_email;
    TextView tv_staff_dob;
    TextInputLayout til_staff_addr;
    TextInputLayout til_staff_contact;
    TextInputLayout til_staff_uname;
    TextInputLayout til_staff_pass;

    EditText et_staff_name;
    EditText et_staff_email;
    EditText et_staff_dob;
    EditText et_staff_addr;
    EditText et_staff_contact;
    EditText et_staff_uname;
    EditText et_staff_pass;

    RadioButton rb_staff_male;
    RadioButton rb_staff_female;
    RadioGroup rb_staff_gender;

    Button btn_staff_add;

    TextView tv_logout;


    public Adminaddstaff() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_adminaddstaff,container,false);

        initViews(view);
        iniData();
        initListeners();
        databaseHelper=new DatabaseHelper(getActivity());

        return view;
    }

    private void iniData() {
        calendar=Calendar.getInstance();
    }

    private void initListeners() {
        btn_staff_add.setOnClickListener(this);
        tv_logout.setOnClickListener(this);
        tv_staff_dob.setOnClickListener(this);
    }

    private void initViews(View view) {
        til_staff_name=view.findViewById(R.id.fragment_admin_add_staff_til_name);
        til_staff_addr=view.findViewById(R.id.fragment_admin_add_staff_til_Email);
        til_staff_contact=view.findViewById(R.id.fragment_admin_add_staff_til_contact);
        tv_staff_dob=view.findViewById(R.id.fragment_admin_add_staff_til_dob);
        til_staff_email=view.findViewById(R.id.fragment_admin_add_staff_til_Email);
        til_staff_uname=view.findViewById(R.id.fragment_admin_add_staff_til_staff_uname);
        til_staff_pass=view.findViewById(R.id.fragment_admin_add_staff_til_staff_pass);

        et_staff_addr=view.findViewById(R.id.fragment_admin_add_staff_et_addr);
        et_staff_name=view.findViewById(R.id.fragment_admin_add_staff_et_name);
        et_staff_email=view.findViewById(R.id.fragment_admin_add_staff_et_Email);
        et_staff_contact=view.findViewById(R.id.fragment_admin_add_staff_et_Email);
//        et_staff_dob=view.findViewById(R.id.fragment_admin_add_staff_et_dob);
        et_staff_uname=view.findViewById(R.id.fragment_admin_add_staff_et_staff_uname);
        et_staff_pass=view.findViewById(R.id.fragment_admin_add_staff_et_staff_pass);

       rb_staff_gender=view.findViewById(R.id.fragment_admin_add_staff_rb_gender);
        rb_staff_male=view.findViewById(R.id.fragment_admin_add_staff_rb_male);
        rb_staff_female=view.findViewById(R.id.fragment_admin_add_staff_rb_female);

        btn_staff_add=view.findViewById(R.id.fragment_admin_add_staff_btn_register);
        tv_logout=view.findViewById(R.id.tv_logout);

    }

    @Override
    public void onClick(View view) {
        switch(view.getId())
        {
            case R.id.fragment_admin_add_staff_btn_register:
                if(validateName() & validateUserName() & validatePass() & validateEmail() & validateDob() & validateAddr() & validateContact()) {
                    int gender = rb_staff_gender.getCheckedRadioButtonId();
                    if (gender == R.id.fragment_admin_add_staff_rb_male)
                        Setgender = "Male";
                    else if (gender == R.id.fragment_admin_add_staff_rb_female)
                        Setgender = "Female";
//                validateform();
                    final long res = databaseHelper.addStaff(setValues(Setgender));
                    if (res != 0L) {
                        final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                        builder.setTitle("Staff Added");
                        builder.setMessage("Staff with id " + res + " added.");
                        builder.setPositiveButton("OK", new DialogInterface
                                .OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialog,
                                                int which) {
                                FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                                Adminoptions adminoptions = new Adminoptions();
                                fragmentTransaction.replace(R.id.main_admin_fl_container, adminoptions, adminoptions.getTag()).commit();
//                            fragmentTransaction.addToBackStack(adminoptions.getTag());
                                FragmentManager fm = getActivity().getSupportFragmentManager();
                                for (int i = 0; i < fm.getBackStackEntryCount(); ++i) {
                                    fm.popBackStack();
                                }

                            }
                        });
                        builder.setCancelable(false);
                        AlertDialog alertDialog = builder.create();
                        alertDialog.show();

                    }
                }
                break;

            case R.id.fragment_admin_add_staff_til_dob:
                showDatePickerDialog();
                break;

            case R.id.tv_logout:
                logout();
                break;
        }
    }

    private StaffPojo setValues(String gender) {
        StaffPojo staffPojo=new StaffPojo();
        staffPojo.setS_name(et_staff_name.getText().toString().trim());
        staffPojo.setS_uname(et_staff_uname.getText().toString().trim());
        staffPojo.setS_pass(et_staff_pass.getText().toString().trim());
        staffPojo.setS_email(et_staff_email.getText().toString().trim());
        staffPojo.setS_dob(tv_staff_dob.getText().toString().trim());
        staffPojo.setS_gender(gender);
        staffPojo.setS_addr(et_staff_addr.getText().toString().trim());
        staffPojo.setS_contact(et_staff_contact.getText().toString().trim());
        return staffPojo;
    }

    private boolean validateName() {
        if(et_staff_name.getText().toString().isEmpty()) {
            til_staff_name.setError("Field Cannot Be Empty.");
            return false;
        }
        else
        {
            til_staff_name.setError(null);
            return true;
        }
    }

    private boolean validateUserName() {
        if(et_staff_uname.getText().toString().isEmpty()) {
            til_staff_uname.setError("Field Cannot Be Empty.");
            return false;
        }
        else
        {
            til_staff_uname.setError(null);
            return true;
        }
    }

    private boolean validatePass() {
        if(et_staff_pass.getText().toString().isEmpty()) {
            til_staff_pass.setError("Field Cannot Be Empty.");
            return false;
        }
        else
        {
            til_staff_pass.setError(null);
            return true;
        }
    }
    private boolean validateEmail() {
        if(et_staff_email.getText().toString().isEmpty()) {
            et_staff_email.setError("Field Cannot Be Empty.");
            return false;
        }
        else
        {
            et_staff_email.setError(null);
            return true;
        }
    }

//    TODO validaion for age greater than 18 yrs and fix db entry
    private boolean validateDob() {

        if(tv_staff_dob.getText().toString().isEmpty()) {
            tv_staff_dob.setError("Field Cannot Be Empty.");
            return false;
        }
        int year=Integer.parseInt(tv_staff_dob.getText().toString().substring(6));
        int diff=Calendar.getInstance().get(Calendar.YEAR)-year;
         if(diff<18){

            final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
            builder.setTitle("Age Limit.");
            builder.setMessage("Staff should be atleast 18 years old."+diff+year);
            builder.setPositiveButton("OK", new DialogInterface
                    .OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog,
                                    int which) {
                }
            });
            builder.setCancelable(false);
            AlertDialog alertDialog = builder.create();
            alertDialog.show();
            return false;


        }

        else
        {
            tv_staff_dob.setError(null);
            return true;
        }
    }
    private boolean validateAddr() {
        if(et_staff_addr.getText().toString().isEmpty()) {
            et_staff_addr.setError("Field Cannot Be Empty.");
            return false;
        }
        else
        {
            et_staff_addr.setError(null);
            return true;
        }
    }
    private boolean validateContact() {
        if(et_staff_contact.getText().toString().isEmpty()) {
            til_staff_contact.setError("Field Cannot Be Empty.");
            return false;
        }
        else
        {
            til_staff_contact.setError(null);
            return true;
        }
    }



    private void showDatePickerDialog(){
        DatePickerDialog datePickerDialog = new DatePickerDialog(getActivity(), this, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
        datePickerDialog.getDatePicker().setMaxDate(Calendar.getInstance().getTimeInMillis());
        datePickerDialog.show();
    }
    @Override
    public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
        calendar.set(i, i1, i2);

        String date;
        String month;

        if(i2 < 10){
            date = "0" + i2;
        }
        else{
            date = String.valueOf(i2);
        }

        if(i1 < 9){
            month = "0" + (i1 + 1);
        }
        else{
            month = String.valueOf(i1 + 1);
        }

        tv_staff_dob.setText(date + "-" + month + "-" + i);
    }


    private void logout() {
        final android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(getActivity());

        builder.setTitle("Log Out?");
        builder.setMessage("Do you really want to log out.");
        builder.setPositiveButton("Yes", new DialogInterface
                .OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog,
                                int which) {

                getFragmentManager().popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
                Intent intent = new Intent(getActivity().getApplicationContext(), LoginOptions.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);

            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        builder.setCancelable(false);
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }
}
