package com.annotation.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.annotation.couriercoverage.R;
import com.annotation.pojo.RequestPojo;


import java.util.List;

public class RequestAdapter extends BaseAdapter {
    private Context context;
    private LayoutInflater inflater;
    private List<RequestPojo> item;

    public RequestAdapter(Context context, List<RequestPojo> item) {
        this.context = context;
        this.item = item;
    }

    @Override
    public int getCount() {
        return item.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        if (inflater==null){
            inflater=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }
        if (view==null){
            view=inflater.inflate(R.layout.view_request_item,null);
        }
        LinearLayout linearLayout=view.findViewById(R.id.linear);
        TextView tv_rid=view.findViewById(R.id.r_id);
        TextView tv_desc=view.findViewById(R.id.r_desc);
        TextView tv_cid=view.findViewById(R.id.r_c_id);

//        tv_rid.setText("Request Id");
//        tv_desc.setText("Description");
//        tv_cid.setText("Customer Id");

        RequestPojo requestPojo=item.get(i);
        int r_id=requestPojo.getR_id();
        String decs=requestPojo.getR_description();
        int c_id=requestPojo.getR_c_id();

        linearLayout.setTag(r_id);
        tv_rid.setText(Integer.toString(r_id));
        tv_desc.setText(decs);
        tv_cid.setText(Integer.toString(c_id));
        return view;
    }
}
