package com.annotation.pojo;

public class StaffPojo {
    private int s_id;
    private String s_name;
    private String s_uname;
    private String s_pass;
    private String s_email;
    private String s_dob;
    private String s_gender;
    private String s_addr;
    private String s_contact;

    public int getS_id() {
        return s_id;
    }

    public void setS_id(int s_id) {
        this.s_id = s_id;
    }

    public String getS_name() {
        return s_name;
    }

    public void setS_name(String s_name) {
        this.s_name = s_name;
    }

    public String getS_uname() {
        return s_uname;
    }

    public void setS_uname(String s_uname) {
        this.s_uname = s_uname;
    }

    public String getS_pass() {
        return s_pass;
    }

    public void setS_pass(String s_pass) {
        this.s_pass = s_pass;
    }

    public String getS_email() {
        return s_email;
    }

    public void setS_email(String s_email) {
        this.s_email = s_email;
    }

    public String getS_dob() {
        return s_dob;
    }

    public void setS_dob(String s_dob) {
        this.s_dob = s_dob;
    }

    public String getS_gender() {
        return s_gender;
    }

    public void setS_gender(String s_gender) {
        this.s_gender = s_gender;
    }

    public String getS_addr() {
        return s_addr;
    }

    public void setS_addr(String s_addr) {
        this.s_addr = s_addr;
    }

    public String getS_contact() {
        return s_contact;
    }

    public void setS_contact(String s_contact) {
        this.s_contact = s_contact;
    }
}
