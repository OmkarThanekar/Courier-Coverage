package com.annotation.fragments;


import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.provider.ContactsContract;
import android.text.style.UpdateAppearance;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.annotation.couriercoverage.LoginOptions;
import com.annotation.couriercoverage.R;
import com.annotation.database.DatabaseHelper;
import com.annotation.pojo.RequestPojo;

/**
 * A simple {@link Fragment} subclass.
 */
public class RequestInfo extends Fragment implements View.OnClickListener {

    TextView tv1;
    TextView tv2;
    TextView tv3;
    TextView tv4;
    TextView tv5;
    TextView tv6;
    TextView tv7;
    TextView tv8;
    TextView tv9;
    TextView tv10;
    TextView tv11;
    TextView tv12;
    TextView tv13;
    TextView tv_logout;


    private Button btn_approve;
    private Button btn_update;

    ConstraintLayout constraintLayout;



    DatabaseHelper databaseHelper;
    int request_id,s_id,c_id;
    String mode;
    String user;
    RequestPojo requestPojo;

    public RequestInfo() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_request_info,container,false);
        databaseHelper=new DatabaseHelper(getActivity());
        request_id=getArguments().getInt("RequestId");
        s_id=getArguments().getInt("StaffId");
        mode=getArguments().getString("mode");
        user=getArguments().getString("user");
        final int sdk = android.os.Build.VERSION.SDK_INT;
        initViews(view);
        if(sdk > Build.VERSION_CODES.KITKAT) {
            constraintLayout.setBackground(ContextCompat.getDrawable(getActivity(), R.drawable.background));

        }

        initListeners();

        return view;
    }



    private void initListeners() {
        btn_approve.setOnClickListener(this);
        btn_update.setOnClickListener(this);
        tv_logout.setOnClickListener(this);
    }

    private void initViews(View view) {
         tv1=view.findViewById(R.id.r_id);
         tv2=view.findViewById(R.id.r_desc);
        tv3=view.findViewById(R.id.r_wt);
        tv4=view.findViewById(R.id.r_frm_addr);
        tv5=view.findViewById(R.id.r_to_addr);
        tv6=view.findViewById(R.id.r_recpt_name);
        tv7=view.findViewById(R.id.r_recpt_contact);
        tv8=view.findViewById(R.id.r_status);
        tv9=view.findViewById(R.id.r_cost);
        tv10=view.findViewById(R.id.r_dop);
        tv11=view.findViewById(R.id.r_c_id);
        tv12=view.findViewById(R.id.r_s_id);
        tv13=view.findViewById(R.id.r_loc);
        tv_logout=view.findViewById(R.id.tv_logout);
        constraintLayout=view.findViewById(R.id.fragment_request_info_cl);


        btn_approve=view.findViewById(R.id.fragment_request_info_btn_approve);
        btn_update=view.findViewById(R.id.fragment_request_info_btn_update);

        if (mode=="approved")
        {
            btn_approve.setEnabled(false);
            btn_approve.setVisibility(View.INVISIBLE);
            btn_update.setEnabled(false);
            btn_update.setVisibility(View.INVISIBLE);
        }
        else if(mode=="update")
        {
            btn_approve.setEnabled(false);
            btn_approve.setVisibility(View.INVISIBLE);
            btn_update.setEnabled(true);
            btn_update.setVisibility(View.VISIBLE);
        }
        else if (mode=="view" && user=="customer")
        {
            btn_approve.setEnabled(false);
            btn_approve.setVisibility(View.INVISIBLE);
            btn_update.setEnabled(false);
            btn_update.setVisibility(View.INVISIBLE);
        }




        requestPojo=databaseHelper.requestInfo(request_id+1);

        tv1.setText( Integer.toString(requestPojo.getR_id()));
        tv2.setText(requestPojo.getR_description());
        tv3.setText(requestPojo.getR_wt());
        tv4.setText(requestPojo.getR_from());
        tv5.setText(requestPojo.getR_to());
        tv6.setText(requestPojo.getR_recpt_name());
        tv7.setText(requestPojo.getR_recpt_contact());
        tv8.setText(requestPojo.getR_status());
        tv9.setText(requestPojo.getR_cost());
        tv10.setText(requestPojo.getR_dop());
        tv11.setText(Integer.toString(requestPojo.getR_c_id()));
        tv12.setText(Integer.toString(requestPojo.getR_s_id()));
        tv13.setText(requestPojo.getR_location());
//        Toast.makeText(getActivity(), "r id="+request_id, Toast.LENGTH_SHORT).show();

//rid gion -1
    }

    @Override
    public void onClick(View view) {
        switch (view.getId())
        {
            case R.id.fragment_request_info_btn_approve:

//                int numOfRows = databaseHelper.updateStatus(requst_id+1);
//                if(numOfRows > 0){
////                    Toast.makeText(getActivity(), "No. of rows impacted: " + numOfRows, Toast.LENGTH_LONG).show();
//                    tv8.setText("Courier Status: Approved");
//                    final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
//                    builder.setTitle("Request Approved.");
//                    builder.setMessage("Request Having Id "+ (requst_id+1) +" Approved.");
//                    builder.setPositiveButton("OK", new DialogInterface
//                            .OnClickListener() {
//
//                        @Override
//                        public void onClick(DialogInterface dialog,
//                                            int which) {
//
//                        }
//                    });
//                    builder.setCancelable(false);
//                    AlertDialog alertDialog = builder.create();
//                    alertDialog.show();
//                }

                ApproveRequest approveRequest=new ApproveRequest();
                Bundle args=new Bundle();
                args.putInt("Request Id",request_id);
                approveRequest.setArguments(args);
                FragmentManager fragmentManager=getActivity().getSupportFragmentManager();
                FragmentTransaction fragmentTransaction=fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.main_admin_fl_container,approveRequest,approveRequest.getTag()).commit();
                fragmentTransaction.addToBackStack(approveRequest.getTag());
                break;

            case R.id.fragment_request_info_btn_update:

                UpdateLocation updateLocation=new UpdateLocation();
                Bundle args1=new Bundle();
                args1.putInt("RequestId",request_id);
                args1.putInt("StaffId",s_id);
                updateLocation.setArguments(args1);
                FragmentManager fragmentManager1=getActivity().getSupportFragmentManager();
                FragmentTransaction fragmentTransaction1=fragmentManager1.beginTransaction();
                fragmentTransaction1.replace(R.id.main_staff_fl_container,updateLocation,updateLocation.getTag()).commit();
                fragmentTransaction1.addToBackStack(updateLocation.getTag());
                break;
            case R.id.tv_logout:
                logout();
                break;
        }
    }

    private void logout() {
        final android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(getActivity());

        builder.setTitle("Log Out?");
        builder.setMessage("Do you really want to log out.");
        builder.setPositiveButton("Yes", new DialogInterface
                .OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog,
                                int which) {

                getFragmentManager().popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
                Intent intent = new Intent(getActivity().getApplicationContext(), LoginOptions.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);

            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        builder.setCancelable(false);
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }
}
