package com.annotation.fragments;


import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;
import androidx.arch.core.executor.DefaultTaskExecutor;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.annotation.couriercoverage.LoginOptions;
import com.annotation.couriercoverage.R;
import com.annotation.database.DatabaseHelper;
import com.annotation.pojo.RequestPojo;
import com.google.android.material.textfield.TextInputLayout;

/**
 * A simple {@link Fragment} subclass.
 */
public class UpdateLocation extends Fragment implements View.OnClickListener {

    private TextInputLayout til_location;
    private EditText et_location;
    private Button btn_update_location;
    private TextView tv_logout;
    ConstraintLayout constraintLayout;
    DatabaseHelper databaseHelper;
    int request_id,s_id,c_id;

    public UpdateLocation() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_update_location,container,false);
        databaseHelper=new DatabaseHelper(getActivity());
        request_id=getArguments().getInt("RequestId");
        s_id=getArguments().getInt("StaffId");

        initViews(view);
        final int sdk = android.os.Build.VERSION.SDK_INT;
        if(sdk > Build.VERSION_CODES.KITKAT) {
            constraintLayout.setBackground(ContextCompat.getDrawable(getActivity(), R.drawable.background));

        }

        initListeners();

        return view;
    }

    private void initListeners() {
        btn_update_location.setOnClickListener(this);
        tv_logout.setOnClickListener(this);
    }

    private void initViews(View view) {
        til_location=view.findViewById(R.id.fragment_update_location_til_location);
        et_location=view.findViewById(R.id.fragment_update_location_et_location);
        btn_update_location=view.findViewById(R.id.fragment_update_location_btn_update_location);
        constraintLayout=view.findViewById(R.id.fragment_update_location_cl);
        tv_logout=view.findViewById(R.id.tv_logout);

//        Toast.makeText(getContext(), "rid="+request_id, Toast.LENGTH_SHORT).show();

    }

    @Override
    public void onClick(View view) {
        switch(view.getId())
        {
            case R.id.fragment_update_location_btn_update_location:
                if (validateForm()) {

                    int numOfRows = databaseHelper.updateLocation(setValues());
                    if (numOfRows > 0) {
//                    Toast.makeText(getActivity(), "No. of rows impacted: " + numOfRows, Toast.LENGTH_LONG).show();

                        final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                        builder.setTitle("Location Updated.");
                        builder.setMessage("Package With Id " + (request_id + 1) + " is at " + et_location.getText().toString());
                        builder.setPositiveButton("OK", new DialogInterface
                                .OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialog,
                                                int which) {
                                FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                                StaffOptions staffOptions = new StaffOptions();
                                Bundle args = new Bundle();
                                args.putInt("StaffId", s_id);
                                staffOptions.setArguments(args);
                                fragmentTransaction.replace(R.id.main_staff_fl_container, staffOptions, staffOptions.getTag()).commit();
//                            fragmentTransaction.addToBackStack(adminoptions.getTag());
                                FragmentManager fm = getActivity().getSupportFragmentManager();
                                for (int i = 0; i < fm.getBackStackEntryCount(); ++i) {
                                    fm.popBackStack();
                                }
                            }
                        });
                        builder.setCancelable(false);
                        AlertDialog alertDialog = builder.create();
                        alertDialog.show();
                    }
                }
                break;
            case R.id.tv_logout:
                logout();
                break;

        }
    }

    private boolean validateForm() {
        if(et_location.getText().toString().isEmpty())
        {
            et_location.setError("Field Cannot Be Empty.");
            return false;
        }
        else return true;
    }

    private void logout() {
        final android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(getActivity());

        builder.setTitle("Log Out?");
        builder.setMessage("Do you really want to log out.");
        builder.setPositiveButton("Yes", new DialogInterface
                .OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog,
                                int which) {
                getFragmentManager().popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
                Intent intent = new Intent(getActivity().getApplicationContext(), LoginOptions.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);

            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        builder.setCancelable(false);
        android.app.AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    private RequestPojo setValues() {
        RequestPojo requestPojo=new RequestPojo();
        requestPojo.setR_id(request_id+1);
        requestPojo.setR_location(et_location.getText().toString().trim());
        return requestPojo;
    }
}
