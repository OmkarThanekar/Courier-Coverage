package com.annotation.fragments;


import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.annotation.couriercoverage.R;
import com.annotation.database.DatabaseHelper;
import com.annotation.pojo.CustomerPojo;
import com.google.android.material.textfield.TextInputLayout;

import java.util.Calendar;

/**
 * A simple {@link Fragment} subclass.
 */
public class CustomerRegistration extends Fragment implements View.OnClickListener, DatePickerDialog.OnDateSetListener {

    DatabaseHelper databaseHelper;
    CustomerPojo customerPojo;
    String Setgender;
    private Calendar calendar;


    private TextInputLayout til_uname;
    private TextInputLayout til_password;
    private TextInputLayout til_email;
    private TextView tv_dob;
    private TextInputLayout til_addr;
    private TextInputLayout til_contact;
    private TextInputLayout til_name;


    private EditText et_uname;
    private EditText et_password;
    private EditText et_email;
//    private EditText et_dob;
    private EditText et_addr;
    private EditText et_contact;
    private EditText et_name;

    private RadioGroup rb_gender;
    private RadioButton rb_male;
    private RadioButton rb_female;


    private Button btn_register;


    public CustomerRegistration() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_customer_registration, container, false);

        initViews(view);
        iniData();
        initListeners();
        databaseHelper = new DatabaseHelper(getActivity());

        return view;
    }

    private void iniData() {
        calendar = Calendar.getInstance();
    }

    private void initViews(View view) {
        til_uname = view.findViewById(R.id.fragment_customer_register_til_username);
        til_password = view.findViewById(R.id.fragment_customer_register_til_password);
        til_email = view.findViewById(R.id.fragment_customer_register_til_Email);
        tv_dob = view.findViewById(R.id.fragment_customer_register_til_dob);
        til_addr = view.findViewById(R.id.fragment_customer_register_til_addr);
        til_contact = view.findViewById(R.id.fragment_customer_register_til_contact);
        til_name = view.findViewById(R.id.fragment_customer_register_til_name);

        et_uname = view.findViewById(R.id.fragment_customer_register_et_username);
        et_password = view.findViewById(R.id.fragment_customer_register_et_password);
        et_email = view.findViewById(R.id.fragment_customer_register_et_Email);
//        et_dob=view.findViewById(R.id.fragment_customer_register_et_dob);

        rb_gender = view.findViewById(R.id.fragment_customer_register_rb_gender);
        rb_male = view.findViewById(R.id.fragment_customer_register_rb_male);
        rb_female = view.findViewById(R.id.fragment_customer_register_rb_female);

        et_addr = view.findViewById(R.id.fragment_customer_register_et_addr);
        et_contact = view.findViewById(R.id.fragment_customer_register_et_contact);
        et_name = view.findViewById(R.id.fragment_customer_register_et_name);

        btn_register = view.findViewById(R.id.fragment_customer_register_btn_register);

    }

    private void initListeners() {
        btn_register.setOnClickListener(this);
        tv_dob.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.fragment_customer_register_btn_register:
//                Toast.makeText(getContext(), "Registered", Toast.LENGTH_SHORT).show();
                if (validateName() & validateUserName() & validatePass() & validateEmail() & validateDob() & validateAddr() & validateContact()) {
                    int gender = rb_gender.getCheckedRadioButtonId();
                    if (gender == R.id.fragment_customer_register_rb_male)
                        Setgender = "Male";
                    else if (gender == R.id.fragment_customer_register_rb_female)
                        Setgender = "Female";
                    validateform();
                    long res = databaseHelper.customerRegister(setValues(Setgender));
                    if (res != 0L) {
                        final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                        builder.setTitle("Customer Added");
                        builder.setMessage("Customer with id " + res + " added.");
                        builder.setPositiveButton("OK", new DialogInterface
                                .OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialog,
                                                int which) {
                                FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                                CustomerLogin customerLogin = new CustomerLogin();
                                FragmentManager fm = getActivity().getSupportFragmentManager();
                                for (int i = 0; i < fm.getBackStackEntryCount(); ++i) {
                                    fm.popBackStack();
                                }
                                fragmentTransaction.replace(R.id.main_customer_fl_container, customerLogin, customerLogin.getTag()).commit();
//                            fragmentTransaction.addToBackStack(adminoptions.getTag());

                            }
                        });
                        builder.setCancelable(false);
                        AlertDialog alertDialog = builder.create();
                        alertDialog.show();
                    }
                }
                break;
//                Toast.makeText(getContext(), Setgender, Toast.LENGTH_SHORT).show();
            case R.id.fragment_customer_register_til_dob:
                showDatePickerDialog();
                break;


        }
    }


    private void showDatePickerDialog() {
        DatePickerDialog datePickerDialog = new DatePickerDialog(getActivity(), this, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
        datePickerDialog.getDatePicker().setMaxDate(Calendar.getInstance().getTimeInMillis());
        datePickerDialog.show();
    }

    @Override
    public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
        calendar.set(i, i1, i2);

        String date;
        String month;

        if (i2 < 10) {
            date = "0" + i2;
        } else {
            date = String.valueOf(i2);
        }

        if (i1 < 9) {
            month = "0" + (i1 + 1);
        } else {
            month = String.valueOf(i1 + 1);
        }

        tv_dob.setText(date + "-" + month + "-" + i);
    }

    //    Validation
    private boolean validateName() {
        if (et_name.getText().toString().isEmpty()) {
            til_name.setError("Field Cannot Be Empty.");
            return false;
        } else {
            til_name.setError(null);
            return true;
        }
    }

    private boolean validateUserName() {
        if (et_uname.getText().toString().isEmpty()) {
            til_uname.setError("Field Cannot Be Empty.");
            return false;
        } else {
            til_uname.setError(null);
            return true;
        }
    }

    private boolean validatePass() {
        if (et_password.getText().toString().isEmpty()) {
            til_password.setError("Field Cannot Be Empty.");
            return false;
        } else {
            til_password.setError(null);
            return true;
        }
    }

    private boolean validateEmail() {
        if (et_email.getText().toString().isEmpty()) {
            et_email.setError("Field Cannot Be Empty.");
            return false;
        } else {
            et_email.setError(null);
            return true;
        }
    }

    private boolean validateDob() {
        if (tv_dob.getText().toString().isEmpty()) {
            tv_dob.setError("Field Cannot Be Empty.");
            return false;
        }
        int year = Integer.parseInt(tv_dob.getText().toString().substring(6));
        int diff = Calendar.getInstance().get(Calendar.YEAR) - year;
        if (diff < 18) {

            final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
            builder.setTitle("Age Limit.");
            builder.setMessage("Staff should be atleast 18 years old." + diff + year);
            builder.setPositiveButton("OK", new DialogInterface
                    .OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog,
                                    int which) {
                }
            });
            builder.setCancelable(false);
            AlertDialog alertDialog = builder.create();
            alertDialog.show();
            return false;


        } else {
            tv_dob.setError(null);
            return true;
        }
    }

    private boolean validateAddr() {
        if (et_addr.getText().toString().isEmpty()) {
            et_addr.setError("Field Cannot Be Empty.");
            return false;
        } else {
            et_addr.setError(null);
            return true;
        }
    }

    private boolean validateContact() {
        if (et_contact.getText().toString().isEmpty()) {
            til_contact.setError("Field Cannot Be Empty.");
            return false;
        } else if (et_contact.getText().toString().length() != 10) {
            et_contact.setError("Enter Valid Contact.");
            return false;
        } else {
            til_contact.setError(null);
            return true;
        }
    }

    private CustomerPojo setValues(String gender) {
        customerPojo = new CustomerPojo();
        customerPojo.setC_name(et_name.getText().toString().trim());
        customerPojo.setC_uname(et_uname.getText().toString().trim());
        customerPojo.setC_pass(et_password.getText().toString().trim());
        customerPojo.setC_email(et_email.getText().toString().trim());
        customerPojo.setC_dob(tv_dob.getText().toString().trim());
        customerPojo.setC_gender(gender);
        customerPojo.setC_addr(et_addr.getText().toString().trim());
        customerPojo.setC_contact(et_contact.getText().toString().trim());
        return customerPojo;


    }

    private void validateform() {
//      validation

    }


}
