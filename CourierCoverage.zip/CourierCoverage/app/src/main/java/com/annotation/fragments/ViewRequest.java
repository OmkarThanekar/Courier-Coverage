package com.annotation.fragments;


import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.annotation.Adapter.RequestAdapter;

import com.annotation.couriercoverage.R;
import com.annotation.database.DatabaseHelper;
import com.annotation.pojo.RequestPojo;

import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 */
public class ViewRequest extends Fragment {
    ListView lv_request;
    RequestPojo requestPojo;
    RequestInfo requestInfo;
    DatabaseHelper databaseHelper;

    String user;
    String mode;
    int s_id;
    int c_id;
    public ViewRequest() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_view_request,container,false);
        user=getArguments().getString("user");
        mode=getArguments().getString("mode");
        s_id=getArguments().getInt("StaffId");
        c_id=getArguments().getInt("CustomerId");
        initViews(view);
        initListeners();
        databaseHelper=new DatabaseHelper(getActivity());
        populateData();
        return view;
    }

    private void populateData() {
        if (user=="admin" && mode=="pending") {
            final List<RequestPojo> requestList = databaseHelper.viewAdminPendingRequest();
            RequestAdapter requestAdapter = new RequestAdapter(getContext(), requestList);
//        Toast.makeText(getContext(), "get"+requestList.size(), Toast.LENGTH_SHORT).show();
            lv_request.setAdapter(requestAdapter);
        }
        else  if (user=="admin" && mode=="approved") {
            final List<RequestPojo> requestList = databaseHelper.viewAdminApprovedRequest();
            RequestAdapter requestAdapter = new RequestAdapter(getContext(), requestList);
//        Toast.makeText(getContext(), "get"+requestList.size(), Toast.LENGTH_SHORT).show();
            lv_request.setAdapter(requestAdapter);
        }
        else if (user=="staff" && mode=="pending") {
            final List<RequestPojo> requestList = databaseHelper.viewStaffPendingRequest(s_id);
            RequestAdapter requestAdapter = new RequestAdapter(getContext(), requestList);
//        Toast.makeText(getContext(), "get"+requestList.size(), Toast.LENGTH_SHORT).show();
            lv_request.setAdapter(requestAdapter);
        }
        else if (user=="customer" && mode=="view")
        {
            final List<RequestPojo> requestList = databaseHelper.viewCustomerRequest(c_id);
            RequestAdapter requestAdapter = new RequestAdapter(getContext(), requestList);
//        Toast.makeText(getContext(), "get"+requestList.size(), Toast.LENGTH_SHORT).show();
            lv_request.setAdapter(requestAdapter);
        }
    }

    private void initListeners() {
        lv_request.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                if(user=="admin" && mode=="pending") {
                    requestInfo = new RequestInfo();
                    Bundle args=new Bundle();
                    int r_id=Integer.parseInt(view.getTag().toString());
                    args.putInt("RequestId",r_id-1);
                    view.getTag();
                    args.putString("user","admin");
                    requestInfo.setArguments(args);
                    FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                    fragmentTransaction.replace(R.id.main_admin_fl_container, requestInfo, requestInfo.getTag()).commit();
                    fragmentTransaction.addToBackStack(requestInfo.getTag());
                }
                else if(user=="admin" && mode=="approved") {
                    requestInfo = new RequestInfo();
                    Bundle args=new Bundle();
                    int r_id=Integer.parseInt(view.getTag().toString());
                    args.putInt("RequestId",r_id-1);
                    args.putString("mode","approved");
                    args.putString("user","admin");
                    requestInfo.setArguments(args);
                    FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                    fragmentTransaction.replace(R.id.main_admin_fl_container, requestInfo, requestInfo.getTag()).commit();
                    fragmentTransaction.addToBackStack(requestInfo.getTag());
                }
                else if(user=="staff" && mode=="pending")
                {
                    requestInfo=new RequestInfo();
                    Bundle args=new Bundle();
                    int r_id=Integer.parseInt(view.getTag().toString());
                    args.putInt("RequestId",r_id-1);
                    args.putString("mode","update");
                    args.putString("user","staff");
                    args.putInt("StaffId",s_id);
                    requestInfo.setArguments(args);
                    FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                    fragmentTransaction.replace(R.id.main_staff_fl_container, requestInfo, requestInfo.getTag()).commit();
                    fragmentTransaction.addToBackStack(requestInfo.getTag());
                }
                else if(user=="customer" && mode=="view")
                {
                    requestInfo=new RequestInfo();
                    Bundle args=new Bundle();
                    int r_id=Integer.parseInt(view.getTag().toString());
                    args.putInt("RequestId",r_id-1);
                    args.putString("mode","view");
                    args.putString("user","customer");
                    requestInfo.setArguments(args);
                    FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                    fragmentTransaction.replace(R.id.main_customer_fl_container, requestInfo, requestInfo.getTag()).commit();
                    fragmentTransaction.addToBackStack(requestInfo.getTag());
                }

            }
        });
    }



    private void initViews(View view) {
        lv_request=view.findViewById(R.id.fragment_view_request_lv);
    }

}
