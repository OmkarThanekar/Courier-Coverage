package com.annotation.fragments;


import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.annotation.couriercoverage.LoginOptions;
import com.annotation.couriercoverage.R;
import com.annotation.database.DatabaseHelper;
import com.annotation.pojo.RequestPojo;
import com.google.android.material.textfield.TextInputLayout;

import java.util.Calendar;

/**
 * A simple {@link Fragment} subclass.
 */
public class CustomerRequest extends Fragment implements View.OnClickListener, DatePickerDialog.OnDateSetListener {

    DatabaseHelper databaseHelper;
    private Calendar calendar;
    int c_id;
    private TextInputLayout til_email;
    private TextInputLayout til_description;
    private TextInputLayout til_wt;
    private TextInputLayout til_frm_addr;
    private TextInputLayout til_to_addr;
    private TextInputLayout til_recepient_contact;
    private TextView tv_dop;
    private TextInputLayout til_recepient_name;


    private EditText et_email;
    private EditText et_description;
    private EditText et_wt;
    private EditText et_frm_addr;
    private EditText et_to_addr;
    private EditText et_recepient_contact;
    private EditText et_recepient_name;
    private EditText et_dop;

    private Button btn_request;

    private TextView tv_logout;


    public CustomerRequest() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_customer_request,container,false);

        initViews(view);
        initData();
        initListeners();
        getKeys();
    databaseHelper=new DatabaseHelper(getActivity());
        return view;
    }

    private void initData() {
        calendar = Calendar.getInstance();
    }

    private void getKeys() {
        c_id=getArguments().getInt("CustomerId");
//        Toast.makeText(getContext(), Integer.toString(c_id), Toast.LENGTH_SHORT).show();
    }

    private void initListeners() {
        btn_request.setOnClickListener(this);
        tv_logout.setOnClickListener(this);
        tv_dop.setOnClickListener(this);
    }

    private void initViews(View view) {
        til_email=view.findViewById(R.id.fragment_customer_request_til_Email);
        til_description=view.findViewById(R.id.fragment_customer_requestr_til_description);
        til_wt=view.findViewById(R.id.fragment_customer_requestr_til_weight);
        til_frm_addr=view.findViewById(R.id.fragment_customer_request_til_from_addr);
        til_to_addr=view.findViewById(R.id.fragment_customer_request_til_to_addr);
        til_recepient_contact=view.findViewById(R.id.fragment_customer_request_til_recepient_contact);
        til_recepient_name=view.findViewById(R.id.fragment_customer_request_til_recepient_name);
        tv_dop=view.findViewById(R.id.fragment_customer_request_til_dop);

        et_email=view.findViewById(R.id.fragment_customer_request_et_Email);
        et_description=view.findViewById(R.id.fragment_customer_request_et_description);
        et_wt=view.findViewById(R.id.fragment_customer_request_et_weight);
        et_frm_addr=view.findViewById(R.id.fragment_customer_request_et_from_addr);
        et_to_addr=view.findViewById(R.id.fragment_customer_request_et_to_addr);
        et_recepient_contact=view.findViewById(R.id.fragment_customer_request_et_recepient_contact);
        et_recepient_name=view.findViewById(R.id.fragment_customer_request_et_recepient_name);
//        et_dop=view.findViewById(R.id.fragment_customer_request_et_dop);

        btn_request=view.findViewById(R.id.fragment_customer_request_btn_request);
        tv_logout=view.findViewById(R.id.tv_logout);

    }


    @Override
    public void onClick(View view) {
        switch(view.getId())
        {
            case R.id.fragment_customer_request_btn_request:
//                Toast.makeText(getContext(), "Request Success", Toast.LENGTH_SHORT).show();
                if (validateEmail() & validateDesc() & validateWt() & validateFromAddr() & validateRecptName() & validateToAddr() & validateRecptContact() & validatedop()) {
                    final long res = databaseHelper.addRequest(setValues());
                    if (res != 0L) {
                        final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                        builder.setTitle("Request Sucessfull");
                        builder.setMessage("Request Id is " + res + ".");
                        builder.setPositiveButton("OK", new DialogInterface
                                .OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialog,
                                                int which) {
                                FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                                Customeroptions customeroptions = new Customeroptions();
                                Bundle args = new Bundle();
                                args.putInt("CustomerId", c_id);
                                customeroptions.setArguments(args);
                                fragmentTransaction.replace(R.id.main_customer_fl_container, customeroptions, customeroptions.getTag()).commit();
//                            fragmentTransaction.addToBackStack(adminoptions.getTag());
                                FragmentManager fm = getActivity().getSupportFragmentManager();
                                for (int i = 0; i < fm.getBackStackEntryCount(); ++i) {
                                    fm.popBackStack();
                                }

                            }
                        });
                        builder.setCancelable(false);
                        AlertDialog alertDialog = builder.create();
                        alertDialog.show();

                    }
                }
                break;
            case R.id.fragment_customer_request_til_dop:
                showDatePickerDialog();
                break;
            case R.id.tv_logout:
                logout();
                break;
        }
    }

    private void showDatePickerDialog(){
        DatePickerDialog datePickerDialog = new DatePickerDialog(getActivity(), this, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
        datePickerDialog.getDatePicker().setMinDate(Calendar.getInstance().getTimeInMillis());
        datePickerDialog.show();
    }

    private boolean validatedop() {
        if(tv_dop.getText().toString().isEmpty()) {
            tv_dop.setError("Field Cannot Be Empty.");
            return false;
        }
        else
        {
            tv_dop.setError(null);
            return true;
        }
    }

    private boolean validateRecptContact() {
        if(et_recepient_contact.getText().toString().isEmpty()) {
            til_recepient_contact.setError("Field Cannot Be Empty.");
            return false;
        }
        else if(et_recepient_contact.getText().toString().length()!=10)
        {
            til_recepient_contact.setError("Enter Valid Contact.");
            return false;
        }
        else
        {
            til_recepient_contact.setError(null);
            return true;
        }
    }

    private boolean validateToAddr() {
        if(et_to_addr.getText().toString().isEmpty()) {
            et_to_addr.setError("Field Cannot Be Empty.");
            return false;
        }
        else
        {
            et_to_addr.setError(null);
            return true;
        }
    }

    private boolean validateRecptName() {
        if(et_recepient_name.getText().toString().isEmpty()) {
            til_recepient_name.setError("Field Cannot Be Empty.");
            return false;
        }
        else
        {
            til_recepient_name.setError(null);
            return true;
        }
    }

    private boolean validateFromAddr() {
        if(et_frm_addr.getText().toString().isEmpty()) {
            et_frm_addr.setError("Field Cannot Be Empty.");
            return false;
        }
        else
        {
            et_frm_addr.setError(null);
            return true;
        }
    }

    private boolean validateWt() {
        if(et_wt.getText().toString().isEmpty()) {
            til_wt.setError("Field Cannot Be Empty.");
            return false;
        }
        else
        {
            til_wt.setError(null);
            return true;
        }
    }

    private boolean validateDesc() {
        if(et_description.getText().toString().isEmpty()) {
            et_description.setError("Field Cannot Be Empty.");
            return false;
        }
        else
        {
            et_description.setError(null);
            return true;
        }
    }

    private boolean validateEmail() {
        if(et_email.getText().toString().isEmpty()) {
            et_email.setError("Field Cannot Be Empty.");
            return false;
        }
        else
        {
            et_email.setError(null);
            return true;
        }
    }

    private void logout() {
        final android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(getActivity());

        builder.setTitle("Log Out?");
        builder.setMessage("Do you really want to log out.");
        builder.setPositiveButton("Yes", new DialogInterface
                .OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog,
                                int which) {
                getFragmentManager().popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
                Intent intent = new Intent(getActivity().getApplicationContext(), LoginOptions.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);

            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        builder.setCancelable(false);
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    private RequestPojo setValues() {
        RequestPojo requestPojo=new RequestPojo();
        requestPojo.setR_description(et_description.getText().toString().trim());
        requestPojo.setR_wt(et_wt.getText().toString().trim());
        requestPojo.setR_from(et_frm_addr.getText().toString().trim());
        requestPojo.setR_to(et_to_addr.getText().toString().trim());
        requestPojo.setR_recpt_name(et_recepient_name.getText().toString().trim());
        requestPojo.setR_recpt_contact(et_recepient_contact.getText().toString().trim());
        requestPojo.setR_status("null");
        requestPojo.setR_cost("null");
        requestPojo.setR_dop(tv_dop.getText().toString().trim());
        requestPojo.setR_c_id(c_id);
        requestPojo.setR_s_id(0);
        requestPojo.setR_location("null");
        return requestPojo;
    }

    @Override
    public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
        calendar.set(i, i1, i2);

        String date;
        String month;

        if(i2 < 10){
            date = "0" + i2;
        }
        else{
            date = String.valueOf(i2);
        }

        if(i1 < 9){
            month = "0" + (i1 + 1);
        }
        else{
            month = String.valueOf(i1 + 1);
        }

        tv_dop.setText(date + "-" + month + "-" + i);
    }
}
