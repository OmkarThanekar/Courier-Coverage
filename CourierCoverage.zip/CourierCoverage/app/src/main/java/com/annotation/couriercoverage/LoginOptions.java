package com.annotation.couriercoverage;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class LoginOptions extends AppCompatActivity implements View.OnClickListener {
    private Button btn_admin;
    private Button btn_staff;
    private Button btn_customer;
    private ConstraintLayout constraintLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_options);
        ActionBar actionBar=getSupportActionBar();
        final int sdk = android.os.Build.VERSION.SDK_INT;

        actionBar.setTitle("HOME");
    initViews();
        if(sdk > Build.VERSION_CODES.KITKAT) {
            constraintLayout.setBackground(ContextCompat.getDrawable(getApplicationContext(), R.drawable.background));

        }
    initListners();
    }

    private void initListners() {
        btn_admin.setOnClickListener(this);
        btn_staff.setOnClickListener(this);
        btn_customer.setOnClickListener(this);
    }

    private void initViews(){
        btn_admin=findViewById(R.id.activity_options_btn_admin);
        btn_staff=findViewById(R.id.activity_options_btn_staff);
        btn_customer=findViewById(R.id.activity_options_btn_customer);
        constraintLayout=findViewById(R.id.activity_options_cl);
    }

    @Override
    public void onClick(View view) {
        switch(view.getId())
        {

            case R.id.activity_options_btn_admin:
//                Toast.makeText(this, "admin login", Toast.LENGTH_SHORT).show();
                Intent intent1=new Intent(this, Admin.class);
                startActivity(intent1);
                break;
            case R.id.activity_options_btn_staff:
//                Toast.makeText(this, "staff login", Toast.LENGTH_SHORT).show();
                Intent intent2=new Intent(this, Staff.class);
                startActivity(intent2);
                break;
            case R.id.activity_options_btn_customer:
                Intent intent=new Intent(this, Customer.class);
                startActivity(intent);
                break;
        }

    }
}
