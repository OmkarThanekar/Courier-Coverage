package com.annotation.fragments;


import android.app.AlertDialog;
import android.content.DialogInterface;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.annotation.couriercoverage.Admin;
import com.annotation.couriercoverage.R;
import com.annotation.database.DatabaseHelper;
import com.annotation.pojo.AdminPojo;
import com.google.android.material.textfield.TextInputLayout;

/**
 * A simple {@link Fragment} subclass.
 */
public class AdminLogin extends Fragment implements View.OnClickListener {

    DatabaseHelper databaseHelper;
    AdminPojo adminPojo;

    private TextInputLayout til_uname;
    private TextInputLayout til_password;
    private ImageView imageView;
    private EditText et_uname;
    private EditText et_password;
    private Button btn_login;
    private ConstraintLayout constraintLayout;
    TextView tv_login;


    public AdminLogin() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_admin_login,container,false);
        final int sdk = android.os.Build.VERSION.SDK_INT;
        initViews(view);
        initListeners();
        databaseHelper=new DatabaseHelper(getActivity());
        if(sdk > Build.VERSION_CODES.KITKAT) {
            constraintLayout.setBackground(ContextCompat.getDrawable(getActivity(), R.drawable.background));

        }
        return view;
    }

    private void initListeners() {
        btn_login.setOnClickListener(this);
    }

    private void initViews(View view) {
        til_uname=view.findViewById(R.id.fragment_admin_login_til_username);
        til_password=view.findViewById(R.id.fragment_admin_login_til_password);
        imageView=view.findViewById(R.id.fragment_admin_login_iv_logo);
        et_uname=view.findViewById(R.id.fragment_admin_login_et_username);
        et_password=view.findViewById(R.id.fragment_admin_login_et_password);
        btn_login=view.findViewById(R.id.fragment_admin_login_btn_login);
        tv_login=view.findViewById(R.id.fragment_admin_login_tv);
        constraintLayout=view.findViewById(R.id.fragment_admin_login_cl);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId())
        {
            case R.id.fragment_admin_login_btn_login:

                if(et_uname.getText().toString().isEmpty() && et_password.getText().toString().isEmpty()) {
                    til_uname.setError("Field Cannot Be Empty.");
                    til_password.setError("Field Cannot Be Empty.");
                }
                else if (et_password.getText().toString().isEmpty())
                {
                    til_password.setError("Field Cannot Be Empty.");
                    til_uname.setError(null);
                }
                else if (et_uname.getText().toString().isEmpty())
                {
                    til_uname.setError("Field Cannot Be Empty.");
                    til_password.setError(null);
                }else {
                    boolean result = databaseHelper.adminLogin(setValues());
                    if (result) {
                        FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                        Adminoptions adminoptions = new Adminoptions();
                        fragmentTransaction.replace(R.id.main_admin_fl_container, adminoptions, adminoptions.getTag()).commit();
                        et_uname.setText("");
                        et_password.setText("");
                        til_password.setError(null);
                        til_uname.setError(null);
//                        fragmentTransaction.addToBackStack(adminoptions.getTag());
                    } else {
//                        Toast.makeText(getContext(), "enter right credentials", Toast.LENGTH_SHORT).show();
                        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                        builder.setTitle("Enter Valid Credentials");
                        builder.setMessage("Please Enter Valid Credentials");
                        builder.setPositiveButton("OK", new DialogInterface
                                .OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialog,
                                                int which) {
                                et_uname.setText("");
                                et_password.setText("");
                                til_password.setError("Enter Valid Password.");
                                til_uname.setError("Enter Valid Username.");

                            }
                        });
                        builder.setCancelable(false);
                        AlertDialog alertDialog = builder.create();
                        alertDialog.show();

                    }
                }
                break;
        }
    }

    private AdminPojo setValues() {

        adminPojo=new AdminPojo();
        adminPojo.setAdmin_uanme(et_uname.getText().toString());
        adminPojo.setAdmin_pass(et_password.getText().toString());
        return adminPojo;
    }
}
