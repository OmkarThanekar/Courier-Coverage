package com.annotation.fragments;


import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.annotation.couriercoverage.LoginOptions;
import com.annotation.couriercoverage.R;
import com.annotation.database.DatabaseHelper;
import com.annotation.pojo.RequestPojo;
import com.google.android.material.textfield.TextInputLayout;

/**
 * A simple {@link Fragment} subclass.
 */
public class ApproveRequest extends Fragment implements View.OnClickListener {

    TextInputLayout til_sid;
    TextInputLayout til_cost;

    EditText et_sid;
    EditText et_cost;
    TextView tv_logout;
    ConstraintLayout constraintLayout;

    Button btn_approve;
    int requst_id;
    int s_id;
DatabaseHelper databaseHelper;
    public ApproveRequest() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_approve_request,container,false);
        databaseHelper=new DatabaseHelper(getActivity());
        requst_id=getArguments().getInt("Request Id");

        initViews(view);
        final int sdk = android.os.Build.VERSION.SDK_INT;
        if(sdk > Build.VERSION_CODES.KITKAT) {
            constraintLayout.setBackground(ContextCompat.getDrawable(getActivity(), R.drawable.background));

        }

        initListeners();

        return view;

    }

    private void initListeners() {
        btn_approve.setOnClickListener(this);
        tv_logout.setOnClickListener(this);
    }

    private void initViews(View view) {
        til_cost=view.findViewById(R.id.fragment_approve_request_til_cost);
        til_sid=view.findViewById(R.id.fragment_approve_request_til_cost);

        et_cost=view.findViewById(R.id.fragment_approve_request_et_cost);
        et_sid=view.findViewById(R.id.fragment_approve_request_et_sid);

        btn_approve=view.findViewById(R.id.fragment_approve_request_btn_approve);

        constraintLayout=view.findViewById(R.id.fragment_approve_request_cl);
        tv_logout=view.findViewById(R.id.tv_logout);
    }

    @Override
    public void onClick(View view) {
        switch(view.getId()){
            case R.id.fragment_approve_request_btn_approve:
                if(validateform()) {
                    int numOfRows = databaseHelper.updateStatus(setValues());
                    if (numOfRows > 0) {
//                    Toast.makeText(getActivity(), "No. of rows impacted: " + numOfRows, Toast.LENGTH_LONG).show();
//                    Toast.makeText(getActivity(), "staff id " + et_sid.getText().toString(), Toast.LENGTH_LONG).show();

                        final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                        builder.setTitle("Request Approved.");
                        builder.setMessage("Request Having Id " + (requst_id + 1) + " Approved.");
                        builder.setPositiveButton("OK", new DialogInterface
                                .OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialog,
                                                int which) {
                                FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                                Adminoptions adminoptions = new Adminoptions();
                                fragmentTransaction.replace(R.id.main_admin_fl_container, adminoptions, adminoptions.getTag()).commit();
//                            fragmentTransaction.addToBackStack(adminoptions.getTag());
                                FragmentManager fm = getActivity().getSupportFragmentManager();
                                for (int i = 0; i < fm.getBackStackEntryCount(); ++i) {
                                    fm.popBackStack();
                                }
                            }
                        });
                        builder.setCancelable(false);
                        AlertDialog alertDialog = builder.create();
                        alertDialog.show();
                    }
                }
                break;
            case R.id.tv_logout:
                logout();
                break;
        }
    }

    private boolean validateform() {
        if(et_sid.getText().toString().isEmpty() && et_cost.getText().toString().isEmpty()) {
            et_sid.setError("Field Cannot Be Empty.");
            et_cost.setError("Field Cannot Be Empty.");
            return false;
        }
        else if (et_sid.getText().toString().isEmpty())
        {
            et_sid.setError("Field Cannot Be Empty.");
            et_cost.setError(null);
            return false;
        }
        else if (et_cost.getText().toString().isEmpty())
        {
            et_cost.setError("Field Cannot Be Empty.");
            et_sid.setError(null);
            return false;
        }
        else
            return true;
    }

    private void logout() {
        final android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(getActivity());

        builder.setTitle("Log Out?");
        builder.setMessage("Do you really want to log out.");
        builder.setPositiveButton("Yes", new DialogInterface
                .OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog,
                                int which) {
                getFragmentManager().popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
                Intent intent = new Intent(getActivity().getApplicationContext(), LoginOptions.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);

            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        builder.setCancelable(false);
        android.app.AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    public RequestPojo setValues()
    {
        RequestPojo requestPojo=new RequestPojo();
        requestPojo.setR_id(requst_id+1);
        requestPojo.setR_s_id(Integer.parseInt(et_sid.getText().toString().trim()));
        requestPojo.setR_cost(et_cost.getText().toString().trim());
        return requestPojo;
    }
}
