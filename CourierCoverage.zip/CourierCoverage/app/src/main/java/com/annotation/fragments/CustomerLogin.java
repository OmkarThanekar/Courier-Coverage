package com.annotation.fragments;


import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.annotation.couriercoverage.R;
import com.annotation.database.DatabaseHelper;
import com.annotation.pojo.CustomerPojo;
import com.google.android.material.textfield.TextInputLayout;


/**
 * A simple {@link Fragment} subclass.
 */
public class CustomerLogin extends Fragment implements View.OnClickListener {
    DatabaseHelper databaseHelper;
    CustomerPojo customerPojo;

    private TextInputLayout til_uname;
    private TextInputLayout til_password;
    private ImageView imageView;
    private EditText et_uname;
    private EditText et_password;
    private Button btn_login;
    private TextView tv_disclaimer;
    TextView tv_login;
    ConstraintLayout constraintLayout;


    public CustomerLogin() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        View view = inflater.inflate(R.layout.fragment_customer_login,container,false);

        initViews(view);
        final int sdk = android.os.Build.VERSION.SDK_INT;
        if(sdk > Build.VERSION_CODES.KITKAT) {
            constraintLayout.setBackground(ContextCompat.getDrawable(getActivity(), R.drawable.background));

        }
        initListeners();
        databaseHelper=new DatabaseHelper(getActivity());

        return view;
    }

    private void initViews(View view) {
        til_uname=view.findViewById(R.id.fragment_customer_login_til_username);
        til_password=view.findViewById(R.id.fragment_customer_login_til_password);

        imageView=view.findViewById(R.id.fragment_customer_login_iv_logo);

        et_uname=view.findViewById(R.id.fragment_customer_login_et_username);
        et_password=view.findViewById(R.id.fragment_customer_login_et_password);

        btn_login=view.findViewById(R.id.fragment_customer_login_btn_login);

        tv_disclaimer=view.findViewById(R.id.fragment_customer_login_tv_disclaimer);
        tv_login=view.findViewById(R.id.fragment_customer_login_tv);

        constraintLayout=view.findViewById(R.id.fragment_customer_login_cl);
    }

    private void initListeners() {
        btn_login.setOnClickListener(this);
        tv_disclaimer.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.fragment_customer_login_btn_login:
//                Toast.makeText(getContext(),"Logged In",Toast.LENGTH_SHORT).show();
//                CustomerRequest customerRequest=new CustomerRequest();
                if(validateForm()){
                boolean result = databaseHelper.customerLogin(setValues());

                if (result) {
                    int c_id=databaseHelper.getCustomerId(setValues());
                    Customeroptions customeroptions = new Customeroptions();
                    Bundle args=new Bundle();
                    args.putInt("CustomerId",c_id);
                    customeroptions.setArguments(args);
                    FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                    fragmentTransaction.replace(R.id.main_customer_fl_container, customeroptions, customeroptions.getTag()).commit();
                    et_uname.setText("");
                    et_password.setText("");
                    til_password.setError(null);
                    til_uname.setError(null);
//                    fragmentTransaction.addToBackStack(customeroptions.getTag());
                } else {
                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                    builder.setTitle("Enter Valid Credentials");
                    builder.setMessage("Please Enter Valid Credentials");
                    builder.setPositiveButton("OK", new DialogInterface
                            .OnClickListener() {

                        @Override
                        public void onClick(DialogInterface dialog,
                                            int which) {
                            et_uname.setText("");
                            et_password.setText("");
                            til_password.setError("Enter Valid Password.");
                            til_uname.setError("Enter Valid Username.");

                        }
                    });
                    builder.setCancelable(false);
                    AlertDialog alertDialog = builder.create();
                    alertDialog.show();
                }
            }
                break;
            case R.id.fragment_customer_login_tv_disclaimer:
                FragmentManager fragmentManager1=getActivity().getSupportFragmentManager();
                FragmentTransaction fragmentTransaction1=fragmentManager1.beginTransaction();
                CustomerRegistration customerRegistration=new CustomerRegistration();
                til_password.setError(null);
                til_uname.setError(null);
                fragmentTransaction1.replace(R.id.main_customer_fl_container,customerRegistration,customerRegistration.getTag()).commit();
//                fragmentTransaction1.addToBackStack(customerRegistration.getTag());
//                FragmentManager fm = getActivity().getSupportFragmentManager();
//                            for(int i = 0; i < fm.getBackStackEntryCount(); ++i) {
//                                fm.popBackStack();
//                            }
                break;
        }

    }

    private boolean validateForm() {
        if(et_uname.getText().toString().isEmpty() && et_password.getText().toString().isEmpty()) {
            til_uname.setError("Field Cannot Be Empty.");
            til_password.setError("Field Cannot Be Empty.");
            return false;
        }
        else if (et_password.getText().toString().isEmpty())
        {
            til_password.setError("Field Cannot Be Empty.");
            til_uname.setError(null);
            return false;
        }
        else if (et_uname.getText().toString().isEmpty())
        {
            til_uname.setError("Field Cannot Be Empty.");
            til_password.setError(null);
            return false;
        }
        else{return true;}

    }

    private CustomerPojo setValues() {
        CustomerPojo customerPojo=new CustomerPojo();
        customerPojo.setC_uname(et_uname.getText().toString());
        customerPojo.setC_pass(et_password.getText().toString());
        return customerPojo;
    }
}
